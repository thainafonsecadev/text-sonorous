using IBM.Cloud.SDK.Core.Authentication.Iam;
using IBM.Watson.TextToSpeech.v1;
using IBM.Watson.TextToSpeech.v1.Model;
using Microsoft.AspNetCore.Http.Connections;
using TextSonorous.Services;

var builder = WebApplication.CreateBuilder(args);

    builder.Services.AddControllers();

    builder.Services.AddSingleton<TextSonorousService>(provider =>

    {
        var confing = builder.Configuration;
        var apikey = confing["IBM:ApiKey"];
        var serviceUrl = confing["IBM: ServiceUrl"];

        return new TextSonorousService(apikey, serviceUrl);

    });

    var app = builder.Build();

    app.UseHttpsRedirection();
    app.UseAuthorization();
    app.MapControllers();
    app.Run();