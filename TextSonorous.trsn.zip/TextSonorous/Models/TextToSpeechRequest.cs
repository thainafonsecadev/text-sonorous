﻿namespace TextSonorous.Models
{
    public class TextToSpeechRequest
    {
        public string Text { get; set; }
        public string Voice { get; set; } = "pt-BR_ThainaV3Voice";
    }


    public class CreateModelRequest

    {
        public string name { get; set; }
        public string language { get; set; } = "pt-Br";
        public string description { get; set; } = " Modelo criado com o SDK.NET";

    }
}
