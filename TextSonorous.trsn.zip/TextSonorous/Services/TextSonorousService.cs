﻿using IBM.Cloud.SDK.Core.Authentication.Iam;
using IBM.Cloud.SDK.Core.Http;
using IBM.Watson.TextToSpeech.v1;
using IBM.Watson.TextToSpeech.v1.Model;
using Microsoft.AspNetCore.ResponseCompression;
using System.IO;
using System.Threading.Tasks;


namespace TextSonorous.Services

{

    public class TextSonorousService
    {
        private readonly TextToSpeechService TextToSpeech;
        private string name;


        public TextSonorousService(string apikey, string serviceUrl)
        {
            IamAuthenticator authenticator = new IamAuthenticator(apikey: apikey);
            TextToSpeech = new TextToSpeechService(authenticator);
            TextToSpeech.SetServiceUrl(serviceUrl);
        }

        public async Task<byte[]> ConvertToSpeechAsync(string text, string voice = "pt-BR_ThainaV3Voice")
        {
            var result = TextToSpeech.Synthesize(
                text: text,
                accept: "audio/mp3",
                voice: voice
            );

            using var memoryStream = new MemoryStream();
            if (result.Result is Stream responseStream)
            {
                await responseStream.CopyToAsync(memoryStream);
            }
            return memoryStream.ToArray();
        }

        public async Task<byte[]> ConvertTextToSpeechAsync(string text, string language = "pt-BR_ThainaV3Voice", string description = "")
        {
            var result = TextToSpeech.CreateCustomModel(
                name: name,
                language: language,
                description: description
            );

            var customModel = result.Result;
            using var memoryStream = new MemoryStream();

            return memoryStream.ToArray();
        }

        internal async Task CreatCustomModelAsync(string name, string language, string description)
        {
            throw new NotImplementedException();
        }
    }
}






