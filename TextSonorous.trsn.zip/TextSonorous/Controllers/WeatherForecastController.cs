using Microsoft.AspNetCore.Mvc;
using TextSonorous.Services;
using TextSonorous.Models;

    namespace TextSonorous.Controllers
{
        [ApiController]
         [Route("[controller]")]
    public class TextToSpeechController : ControllerBase
    {
        private readonly TextSonorousService _textService;

        public TextToSpeechController(TextSonorousService textService)
        {
            _textService = textService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateModel([FromBody] CreateModelRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.name))
                return BadRequest("modelo da mensagem");

            await _textService.CreatCustomModelAsync(
                request.name,
                request.language,
                request.description
            );

            return Ok("Modelo criado com sucesso.");
        }
    }
}






